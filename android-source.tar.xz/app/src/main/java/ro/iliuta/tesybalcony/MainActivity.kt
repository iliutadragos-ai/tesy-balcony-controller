package ro.iliuta.tesybalcony

import androidx.activity.ComponentActivity
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var secure: SecureCredentials
    private lateinit var settings: AutomationSettings
    private lateinit var statusView: TextView
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var userIdInput: EditText
    private lateinit var thresholdInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var deviceSpinner: Spinner
    private var discovered = emptyList<TesyDevice>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        secure = SecureCredentials(getSharedPreferences("secure", Context.MODE_PRIVATE))
        settings = AutomationSettings(this)
        buildUi()
        loadSavedValues()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            setBackgroundColor(0xFFF7F5F8.toInt())
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "TESY Balcony Controller"
            textSize = 25f
            setTextColor(0xFF4A1450.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title, matchWrap())
        addText(root, "Control automat pentru convectorul de pe balcon", 14f, 0xFF55515A.toInt(), top = 4)
        addText(root, "Setări inițiale: prag 10°C · pornire 20 min · verificare la 3 ore", 14f, 0xFF4A1450.toInt(), top = 14)

        section(root, "1. Conectare MyTESY")
        emailInput = field(root, "Email MyTESY", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        passwordInput = field(root, "Parolă MyTESY", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        userIdInput = field(root, "MyTESY user ID", InputType.TYPE_CLASS_TEXT)
        addText(root, "Protocolul cloud comunitar necesită email, parolă și user ID. Acesta nu este parola și nici adresa de email.", 12f, 0xFF6B6670.toInt(), top = 3)

        button(root, "Testează conexiunea și caută convectorul") { testConnection() }
        deviceSpinner = Spinner(this)
        root.addView(deviceSpinner, matchWrap().apply { topMargin = dp(8) })

        section(root, "2. Parametrii automatizării")
        thresholdInput = field(root, "Prag temperatură (°C)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        durationInput = field(root, "Durată pornire (minute)", InputType.TYPE_CLASS_NUMBER)
        intervalInput = field(root, "Verificare la fiecare (ore)", InputType.TYPE_CLASS_NUMBER)
        button(root, "Salvează configurația") { saveAll(showMessage = true) }

        section(root, "3. Automatizare")
        button(root, "ACTIVEAZĂ automatizarea") {
            if (!saveAll(showMessage = false)) return@button
            if (settings.selectedMac.isNullOrBlank()) {
                showStatus("Mai întâi testează conexiunea și selectează convectorul.")
            } else {
                AutomationScheduler.start(this, settings.intervalHours)
                AutomationScheduler.checkNow(this)
                showStatus("Automatizare activă. Prima verificare a fost solicitată acum; următoarele vor fi programate la fiecare ${settings.intervalHours} ore.")
            }
        }
        button(root, "Oprește automatizarea", secondary = true) {
            AutomationScheduler.stop(this)
            showStatus("Verificările viitoare au fost oprite. Un ciclu de încălzire deja început își va executa oprirea de siguranță.")
        }
        button(root, "Verifică acum", secondary = true) {
            if (saveAll(showMessage = false)) {
                AutomationScheduler.checkNow(this)
                showStatus("Verificare solicitată. Poate fi amânată de Android dacă telefonul este în economisire agresivă a bateriei.")
            }
        }

        section(root, "Status")
        statusView = TextView(this).apply {
            text = "Neconfigurat. Introdu datele MyTESY și testează conexiunea."
            textSize = 14f
            setTextColor(0xFF333039.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(statusView, matchWrap())
        addText(root, "Important: dacă temperatura nu poate fi citită, aplicația nu pornește încălzirea. Dacă aparatul era deja pornit manual, aplicația nu îl preia și nu îl oprește. Confirmarea se face recitind starea din MyTESY.", 12f, 0xFF6B6670.toInt(), top = 14)
        addText(root, "Aplicație neoficială, independentă de TESY. Necesită internet și cont MyTESY.", 11f, 0xFF817B85.toInt(), top = 12)
    }

    private fun loadSavedValues() {
        secure.load()?.let {
            emailInput.setText(it.email)
            passwordInput.setText(it.password)
            userIdInput.setText(it.userId)
        }
        thresholdInput.setText(settings.thresholdC.toString())
        durationInput.setText(settings.durationMinutes.toString())
        intervalInput.setText(settings.intervalHours.toString())
        val savedMac = settings.selectedMac
        if (!savedMac.isNullOrBlank()) showStatus("Convector memorat: ${savedMac}. Apasă «Testează conexiunea» pentru a verifica starea curentă.")
    }

    private fun testConnection() {
        if (!saveAll(showMessage = false)) return
        val credentials = secure.load() ?: return
        showStatus("Conectare la MyTESY și descoperire dispozitive…")
        lifecycleScope.launch {
            try {
                val devices = TesyCloudClient(credentials).getDevices()
                discovered = devices
                if (devices.isEmpty()) {
                    showStatus("Contul a răspuns, dar nu am găsit un convector compatibil. Nu trimitem comenzi. Verificăm modelul și protocolul.")
                    return@launch
                }
                val labels = devices.map {
                    "${it.name} — ${it.modelType.ifBlank { it.model }} — ${it.currentTempC?.let { t -> String.format(Locale.US, "%.1f°C", t) } ?: "temperatură indisponibilă"}"
                }
                deviceSpinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
                val wanted = settings.selectedMac?.let { TesyCloudClient.normaliseMac(it) }
                val index = devices.indexOfFirst { TesyCloudClient.normaliseMac(it.mac) == wanted }.let { if (it >= 0) it else 0 }
                deviceSpinner.setSelection(index)
                settings.selectedMac = devices[index].mac
                showStatus("Conectare reușită. Găsite ${devices.size} dispozitiv(e). Selectat: ${devices[index].name}, ${devices[index].modelType.ifBlank { devices[index].model }}, ${devices[index].currentTempC ?: "?"}°C. Compatibilitatea CN 052 trebuie confirmată prin acest test pe aparatul tău.")
            } catch (e: Exception) {
                showStatus(e.message ?: "Nu am putut verifica MyTESY.")
            }
        }
    }

    private fun saveAll(showMessage: Boolean): Boolean {
        val email = emailInput.text.toString().trim()
        val password = passwordInput.text.toString()
        val userId = userIdInput.text.toString().trim()
        if (email.isBlank() || password.isBlank() || userId.isBlank()) {
            showStatus("Completează emailul, parola și user ID-ul MyTESY. Nu trimite aceste date în conversație.")
            return false
        }
        val threshold = thresholdInput.text.toString().replace(',', '.').toDoubleOrNull()
        val duration = durationInput.text.toString().toIntOrNull()
        val interval = intervalInput.text.toString().toIntOrNull()
        if (threshold == null || !threshold.isFinite() || threshold !in 0.0..30.0 || duration == null || duration !in 5..60 || interval == null || interval !in 1..12) {
            showStatus("Setări invalide. Prag: 0–30°C; durată: 5–60 minute; interval: 1–12 ore.")
            return false
        }
        secure.save(TesyCredentials(email, password, userId))
        settings.thresholdC = threshold
        settings.durationMinutes = duration
        settings.intervalHours = interval
        if (discovered.isNotEmpty()) {
            val selected = discovered.getOrNull(deviceSpinner.selectedItemPosition)
            if (selected != null) settings.selectedMac = selected.mac
        }
        if (showMessage) showStatus("Configurația a fost salvată pe telefon. Datele contului sunt criptate cu Android Keystore.")
        return true
    }

    private fun field(parent: LinearLayout, label: String, type: Int): EditText {
        addText(parent, label, 13f, 0xFF45414A.toInt(), top = 10)
        return EditText(this).apply {
            inputType = type
            textSize = 16f
            singleLine = true
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFFFFFFFF.toInt())
            parent.addView(this, matchWrap().apply { topMargin = dp(4) })
        }
    }

    private fun section(parent: LinearLayout, title: String) {
        addText(parent, title, 18f, 0xFF4A1450.toInt(), top = 22, bold = true)
    }

    private fun addText(parent: LinearLayout, value: String, size: Float, color: Int, top: Int = 0, bold: Boolean = false) {
        val view = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        parent.addView(view, matchWrap().apply { topMargin = dp(top) })
    }

    private fun button(parent: LinearLayout, label: String, secondary: Boolean = false, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(if (secondary) 0xFF5A155F.toInt() else 0xFFFFFFFF.toInt())
            setBackgroundColor(if (secondary) 0xFFEDE6F1.toInt() else 0xFF6E0B72.toInt())
            setOnClickListener { action() }
        }
        parent.addView(b, matchWrap().apply { topMargin = dp(10) })
    }

    private fun showStatus(value: String) {
        if (::statusView.isInitialized) statusView.text = value
        else Toast.makeText(this, value, Toast.LENGTH_LONG).show()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
