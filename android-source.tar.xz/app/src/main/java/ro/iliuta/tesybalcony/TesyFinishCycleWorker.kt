package ro.iliuta.tesybalcony

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.delay

/** Standalone delayed OFF task; survives stopping periodic checks and app process death. */
class TesyFinishCycleWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val settings = AutomationSettings(context)
    private val secure = SecureCredentials(context.getSharedPreferences("secure", Context.MODE_PRIVATE))

    override suspend fun doWork(): Result {
        val mac = settings.cycleMac
        val startedAt = settings.cycleStartedAt
        if (mac.isNullOrBlank() || startedAt <= 0L) return Result.success()

        val deadline = startedAt + settings.cycleDurationMinutes * 60_000L
        val remaining = deadline - System.currentTimeMillis()
        if (remaining > 0L) {
            // WorkManager should honour the initial delay. If the wall clock moved
            // backwards, retry instead of holding a worker thread for the remainder.
            return Result.retry()
        }

        val credentials = secure.load() ?: return Result.retry()
        return try {
            val client = TesyCloudClient(credentials)
            val device = client.getDevices().firstOrNull {
                TesyCloudClient.normaliseMac(it.mac) == TesyCloudClient.normaliseMac(mac)
            } ?: return Result.retry()

            when (device.statusOn) {
                false -> {
                    // The heater has already been switched off manually.
                    settings.clearCycle()
                    Result.success()
                }
                null -> {
                    // The persisted marker proves this app initiated the cycle.
                    // When cloud status is unknown, still issue an idempotent OFF
                    // using the discovered device token, then require read-back.
                    client.setPower(device, false)
                    if (waitForOff(client, mac)) {
                        settings.clearCycle()
                        Result.success()
                    } else {
                        Result.retry()
                    }
                }
                true -> {
                    client.setPower(device, false)
                    if (waitForOff(client, mac)) {
                        settings.clearCycle()
                        Result.success()
                    } else {
                        Result.retry()
                    }
                }
            }
        } catch (_: TesyCloudException) {
            Result.retry()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private suspend fun waitForOff(client: TesyCloudClient, mac: String): Boolean {
        var consecutiveOff = 0
        repeat(5) { attempt ->
            delay(if (attempt == 0) 2_000L else 3_000L)
            val devices = runCatching { client.getDevices() }.getOrNull()
            val state = devices?.firstOrNull {
                TesyCloudClient.normaliseMac(it.mac) == TesyCloudClient.normaliseMac(mac)
            }?.statusOn
            if (state == false) {
                consecutiveOff++
                if (consecutiveOff >= 2) return true
            } else {
                consecutiveOff = 0
            }
        }
        return false
    }
}
