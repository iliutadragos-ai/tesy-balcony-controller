package ro.iliuta.tesybalcony

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object AutomationScheduler {
    private const val PERIODIC_NAME = "tesy_balcony_temperature_check"
    private const val MANUAL_NAME = "tesy_balcony_manual_check"
    private const val FINISH_NAME = "tesy_balcony_finish_pending_cycle"

    private fun networkConstraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    fun start(context: Context, intervalHours: Int) {
        val request = PeriodicWorkRequestBuilder<TesyCycleWorker>(
            intervalHours.coerceIn(1, 12).toLong(), TimeUnit.HOURS
        )
            .setConstraints(networkConstraints())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
        )
        schedulePendingFinish(context)
    }

    fun stop(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(PERIODIC_NAME)
        // The OFF task has its own persistent work request and is deliberately
        // not cancelled when the user stops future temperature checks.
        schedulePendingFinish(context)
    }

    fun checkNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<TesyCycleWorker>()
            .setConstraints(networkConstraints())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(MANUAL_NAME, ExistingWorkPolicy.KEEP, request)
    }

    fun scheduleFinish(context: Context, delayMs: Long) {
        val request = OneTimeWorkRequestBuilder<TesyFinishCycleWorker>()
            .setInitialDelay(delayMs.coerceAtLeast(0L), TimeUnit.MILLISECONDS)
            .setConstraints(networkConstraints())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            FINISH_NAME, ExistingWorkPolicy.KEEP, request
        )
    }

    private fun schedulePendingFinish(context: Context) {
        val settings = AutomationSettings(context)
        val mac = settings.cycleMac
        val startedAt = settings.cycleStartedAt
        if (!mac.isNullOrBlank() && startedAt > 0L) {
            val deadline = startedAt + settings.cycleDurationMinutes * 60_000L
            scheduleFinish(context, deadline - System.currentTimeMillis())
        }
    }
}
