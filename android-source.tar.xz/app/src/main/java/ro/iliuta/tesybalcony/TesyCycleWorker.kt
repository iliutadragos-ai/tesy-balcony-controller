package ro.iliuta.tesybalcony

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.delay

/** Periodic/manual check. It never waits through a heating cycle; OFF is a separate persisted work request. */
class TesyCycleWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val settings = AutomationSettings(context)
    private val secure = SecureCredentials(context.getSharedPreferences("secure", Context.MODE_PRIVATE))

    override suspend fun doWork(): Result {
        val credentials = secure.load() ?: return Result.failure()
        val activeMac = settings.cycleMac
        val activeStart = settings.cycleStartedAt
        if (!activeMac.isNullOrBlank() && activeStart > 0L) {
            // A previous ON may have succeeded before process death. Never start
            // a second cycle; ensure the independently persisted OFF task exists.
            val deadline = activeStart + settings.cycleDurationMinutes * 60_000L
            AutomationScheduler.scheduleFinish(applicationContext, deadline - System.currentTimeMillis())
            return Result.success()
        }

        val selectedMac = settings.selectedMac ?: return Result.failure()
        return try {
            val client = TesyCloudClient(credentials)
            val device = client.getDevices().firstOrNull {
                TesyCloudClient.normaliseMac(it.mac) == TesyCloudClient.normaliseMac(selectedMac)
            } ?: return Result.retry()
            val current = device.currentTempC ?: return Result.retry()

            // Only a positively reported OFF state is eligible. Unknown status
            // is not treated as OFF, and a manually powered heater is untouched.
            if (!AutomationDecision.shouldStart(current, settings.thresholdC, device.statusOn)) {
                return Result.success()
            }

            val startedAt = System.currentTimeMillis()
            settings.markCycle(device.mac, startedAt, settings.durationMinutes)
            client.setPower(device, true)

            if (waitForStatus(client, device.mac, expectedOn = true, requiredConsecutive = 2)) {
                val deadline = startedAt + settings.cycleDurationMinutes * 60_000L
                AutomationScheduler.scheduleFinish(applicationContext, deadline - System.currentTimeMillis())
                Result.success()
            } else {
                // A cloud publish is not proof the heater accepted ON. Send OFF
                // defensively and require repeated read-back before clearing the
                // cycle marker. Never retry ON in this same attempt.
                val latest = runCatching { client.getDevices().firstOrNull {
                    TesyCloudClient.normaliseMac(it.mac) == TesyCloudClient.normaliseMac(device.mac)
                } }.getOrNull()
                // OFF is idempotent and is sent even if status is unknown.
                client.setPower(latest ?: device, false)
                if (waitForStatus(client, device.mac, expectedOn = false, requiredConsecutive = 2)) {
                    settings.clearCycle()
                    Result.success()
                } else {
                    AutomationScheduler.scheduleFinish(applicationContext, 0L)
                    Result.retry()
                }
            }
        } catch (_: TesyCloudException) {
            // If ON may have been sent, the persisted marker prevents a new cycle
            // and the OFF worker is re-armed on the next scheduler pass.
            val mac = settings.cycleMac
            val start = settings.cycleStartedAt
            if (!mac.isNullOrBlank() && start > 0L) {
                val deadline = start + settings.cycleDurationMinutes * 60_000L
                AutomationScheduler.scheduleFinish(applicationContext, deadline - System.currentTimeMillis())
            }
            Result.retry()
        } catch (_: Exception) {
            val mac = settings.cycleMac
            val start = settings.cycleStartedAt
            if (!mac.isNullOrBlank() && start > 0L) {
                val deadline = start + settings.cycleDurationMinutes * 60_000L
                AutomationScheduler.scheduleFinish(applicationContext, deadline - System.currentTimeMillis())
            }
            Result.retry()
        }
    }

    private suspend fun waitForStatus(
        client: TesyCloudClient,
        mac: String,
        expectedOn: Boolean,
        requiredConsecutive: Int
    ): Boolean {
        var consecutive = 0
        repeat(5) { attempt ->
            delay(if (attempt == 0) 2_000L else 3_000L)
            val latest = runCatching { client.getDevices() }.getOrNull()
            val state = latest?.firstOrNull {
                TesyCloudClient.normaliseMac(it.mac) == TesyCloudClient.normaliseMac(mac)
            }?.statusOn
            if (state == expectedOn) {
                consecutive++
                if (consecutive >= requiredConsecutive) return true
            } else {
                consecutive = 0
            }
        }
        return false
    }
}
