# TESY Balcony Controller (Android)

Android app prototype for a TESY MyTESY cloud convector, intended for a OnePlus phone on Android 15 or newer.

## Initial automation profile

- Temperature threshold: **10°C** (starts only when the reported temperature is strictly below 10°C)
- Requested heating cycle: **20 minutes**
- Temperature check interval: **3 hours**
- Device: selected explicitly from MyTESY discovery

The app only sends ON/OFF commands. It does not change the convector's Eco/Comfort/Sleep setpoint; the convector's own thermostat remains responsible for heat regulation.

## Development status

This is an **alpha source prototype**, not a tested APK. The Android project includes an initial MyTESY cloud adapter, WorkManager automation, encrypted local credentials, and unit tests. The project has not yet been compiled in this environment because Android SDK and Gradle are not installed here. The cloud adapter has not been tested with the user's account or physical CN 052 convector. No CN 052 compatibility claim is made until discovery and supervised ON/OFF tests succeed.

## MyTESY integration

The adapter follows the community-described MyTESY v4 protocol in https://github.com/Kosztyk/homebridge-tesy-native:

- Discovery: `GET https://ad.mytesy.com/rest/get-my-devices`
- Commands: MQTT 3.1.1 over secure WebSocket `wss://mqtt.tesy.com:8083/`
- Topic: `v1/{MAC}/request/{model}/{token}/onOff`
- Payload: `{"app_id":"...","status":"on|off"}`

This is an unofficial community protocol, not a TESY-supported public API. It may change and may behave differently across device generations or accounts. It currently requires MyTESY email, password, and the account's **user ID**. Do not guess the user ID or send credentials in chat.

MQTT QoS 0 publish completion means the client sent the message; it is not a heater acknowledgement. The app polls MyTESY and checks reported status before treating ON/OFF as confirmed. The WebSocket handshake includes the MyTESY web Origin/Referer headers used by the community integration.

## Automation and safety

1. WorkManager requests a temperature check every 3 hours. The first check is requested immediately when automation is enabled.
2. Missing/invalid temperature or unknown power state never triggers heating.
3. If the convector is already ON, the app leaves it alone; it will not adopt a manually started cycle and later switch it OFF.
4. If the convector is confirmed OFF and temperature is below 10°C, the app records an owned cycle, sends ON, and confirms the cloud-reported state.
5. An independent, persistent one-time WorkManager request is scheduled for the 20-minute deadline. It sends OFF and requires repeated cloud read-back. It is not cancelled when future temperature checks are stopped.
6. If cloud status is unknown during an app-owned cycle, the app sends an idempotent OFF and retries until OFF can be confirmed.

**Timing limitation:** Android WorkManager is deferrable scheduling. “Every 3 hours” means a 3-hour interval, not an exact-minute guarantee; the OFF task can also be delayed by Android/OnePlus power management. Doze, battery optimization, network loss, force-stop, phone shutdown, or MyTESY outage can delay or prevent cloud commands. A force-stopped app cannot run background work until reopened. Before unattended use, test discovery and supervise at least one ON/OFF cycle while present. Keep the convector's thermostat and built-in protections enabled.

## Credentials

Email, password, and MyTESY user ID are encrypted with AES-GCM using an Android Keystore key. Credentials are not included in source code. Device control tokens are held only in memory and are not logged or persisted.

## Build

The repository's GitHub Actions workflow extracts `android-source.zip`, installs JDK 17 / Android SDK 36 / Gradle 8.13, runs unit tests, builds a debug APK, and publishes the APK as an Actions artifact for 14 days. Open **Actions → Build Android APK → Run workflow**. Download the artifact `tesy-balcony-controller-debug-apk` and install `app-debug.apk` on the OnePlus. A production release needs a private signing key and release build configuration.

## OnePlus setup

After installation, set the app's battery usage to **Unrestricted** / allow background activity if OxygenOS offers that option. Keep internet available and do not put the app into a deep-sleep or auto-cleanup list.

## Stack

- Android Gradle Plugin 8.13.2; Kotlin Gradle Plugin 2.4.21
- WorkManager 2.12.0; OkHttp 4.12.0; Eclipse Paho MQTT Java 1.2.5
- min API 26; target API 35; compile API 36

Unofficial independent project; not affiliated with or endorsed by TESY.
